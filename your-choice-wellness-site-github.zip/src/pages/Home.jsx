
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Mail, Phone, HeartPulse, Leaf } from "lucide-react";

export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center p-6 space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold">Your Choice Healthcare & Wellness</h1>
        <p className="mt-2 text-lg text-gray-700">
          Empowering you with holistic and clinical care for lasting wellness.
        </p>
      </div>

      <Card className="w-full max-w-4xl">
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
          <div>
            <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
              <HeartPulse /> Our 4-Week Anti-Inflammatory Course
            </h2>
            <p>
              Join our complete health program to reduce inflammation, balance
              hormones, stabilize blood sugar, and improve gut health. Includes meal
              plans, exercise, videos, workbook, and more.
            </p>
            <ul className="list-disc list-inside mt-4 text-sm text-gray-700">
              <li>Weekly guides & recipes</li>
              <li>Beginner-friendly exercises</li>
              <li>Downloadable workbook</li>
              <li>Expert video lessons</li>
              <li>Signup with payment option</li>
            </ul>
            <a href="https://paypal.me/lynnbrown1820" target="_blank" rel="noopener noreferrer">
              <Button className="mt-6">Join the Course</Button>
            </a>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-2">Stay Connected</h2>
            <p className="text-sm text-gray-600 mb-4">
              Subscribe to our newsletter to get health tips, recipes, and program
              updates.
            </p>
            <Input placeholder="Enter your email" className="mb-2" />
            <Button>Subscribe</Button>

            <div className="mt-8 space-y-2 text-sm">
              <p className="flex items-center gap-2">
                <Mail className="w-4 h-4" /> ychcwellness@gmail.com
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4" /> 478-559-3154
              </p>
              <p className="flex items-center gap-2">
                <Leaf className="w-4 h-4" /> 820 2nd Ave, Suite B, Eastman, GA 31023
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
