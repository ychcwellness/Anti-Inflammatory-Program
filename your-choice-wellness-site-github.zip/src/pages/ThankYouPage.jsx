
import React from "react";
import { Button } from "@/components/ui/button";
import { Smile, Download } from "lucide-react";

export default function ThankYouPage() {
  return (
    <main className="flex flex-col items-center justify-center p-10 text-center space-y-6">
      <Smile className="w-12 h-12 text-green-500" />
      <h1 className="text-3xl font-bold">Thank You for Joining!</h1>
      <p className="text-gray-700 max-w-xl">
        Your payment has been received. We're excited to have you on this wellness journey with us. You can now download your course materials and get started!
      </p>
      <a href="/downloads/Your_Choice_Wellness_Course.zip" target="_blank" rel="noopener noreferrer">
        <Button className="flex items-center gap-2">
          <Download className="w-4 h-4" /> Download Course Materials
        </Button>
      </a>
      <p className="text-sm text-gray-600">
        If you have any questions, please contact us at <br />
        <strong>ychcwellness@gmail.com</strong> or call <strong>478-559-3154</strong>.
      </p>
    </main>
  );
}
