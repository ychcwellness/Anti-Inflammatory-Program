
import React from "react";
import { Card, CardContent } from "@/components/ui/card";

export default function CourseInfoPage() {
  return (
    <main className="p-6 max-w-4xl mx-auto space-y-8">
      <section>
        <h1 className="text-3xl font-bold mb-4">4-Week Anti-Inflammatory Program</h1>
        <p className="text-gray-700">
          This step-by-step course is designed to help you heal from the inside out. Whether you struggle with chronic inflammation, diabetes, arthritis, or hormonal imbalance, this program combines holistic nutrition, simple movement, and scientific education to support your whole-body wellness.
        </p>
      </section>

      <Card>
        <CardContent className="p-6 space-y-2">
          <h2 className="text-xl font-semibold">What’s Included:</h2>
          <ul className="list-disc list-inside text-gray-700">
            <li>Weekly meal plans, recipes, and grocery lists</li>
            <li>Beginner-level workouts (walking, chair, light weights)</li>
            <li>Educational modules on gut health, blood sugar, hormones</li>
            <li>Downloadable workbook and journaling tools</li>
            <li>Video tutorials and printable PDFs</li>
            <li>Supportive tools to promote long-term success</li>
          </ul>
        </CardContent>
      </Card>

      <section>
        <h2 className="text-2xl font-semibold mt-8">Meet Your Instructor</h2>
        <p className="text-gray-700 mt-2">
          <strong>Pamela Lynn Brown</strong> is a dedicated healthcare provider with decades of experience in wellness, primary care, and hormone optimization. Her passion lies in helping others reclaim control over their health using an integrated, personalized approach. Pamela is the founder of Your Choice Healthcare & Wellness, based in Eastman, Georgia.
        </p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mt-8">Frequently Asked Questions</h2>
        <ul className="list-disc list-inside text-gray-700 mt-2 space-y-2">
          <li>
            <strong>Do I need a gym or equipment?</strong> No. All exercises can be done at home using your body weight or light dumbbells.
          </li>
          <li>
            <strong>Is this program safe for diabetics or people with high blood pressure?</strong> Yes. It’s designed specifically with these conditions in mind.
          </li>
          <li>
            <strong>How long will I have access to the materials?</strong> You’ll get lifetime access to the PDFs and video links once you enroll.
          </li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mt-8">Client Testimonials</h2>
        <blockquote className="italic border-l-4 border-green-500 pl-4 text-gray-600">
          “I lost 12 pounds in a month and feel more energetic than I have in years!” – M. J.
        </blockquote>
        <blockquote className="italic border-l-4 border-green-500 pl-4 text-gray-600 mt-4">
          “This program helped me understand how food affects my inflammation. The recipes are simple and delicious!” – T. K.
        </blockquote>
      </section>
    </main>
  );
}
